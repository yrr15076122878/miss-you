﻿注：如发现配置了，但是页面不起作用，请清理浏览器缓存。

1.页面入口为 ：index.html
2.配置项存在 Printdemo/js/configItem.js 中 的 config 对象中配置，js 中配置有说明。
3.需要修改胸卡中的宽高，背景图片及文字位置：css/configCss.css














