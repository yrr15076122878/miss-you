﻿
//页面配置项
var config = {
	nameInput : true ,    //姓名输入框个数     true:一个    false:两个
    companyPatt:false,     //是否隐藏公司       隐藏：true    显示：false
    barcodeNum:8,          //条码的字符串长度，后台提供时可忽略。
    getBarcodeNum: "b",     //条码获取途径       "b" : 后台提供  "f" : 页面输入
    country_province:true, //是否显示国家省份   true ：显示   false：不显示
    position:false ,        //是否显示职位       true ：显示   false：不显示
    test:false              //是否为测试模式(仅有打印功能，不保存数据到后台)     true :  是    false: 否
}











