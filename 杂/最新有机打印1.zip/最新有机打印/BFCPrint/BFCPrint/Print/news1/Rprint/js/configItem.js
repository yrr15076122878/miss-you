

//页面配置项

var config = {
    country_province: false, //是否显示国家省份   true ：显示   false：不显示
    position:false         //是否显示职位       true ：显示   false：不显示
}










