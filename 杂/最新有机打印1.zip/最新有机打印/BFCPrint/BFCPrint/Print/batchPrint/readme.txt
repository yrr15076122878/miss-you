
批量打印：bulkPrint.html
样式调整的css路径：css/configCss.css



批量打印模板（笔填卡片）：bulkPrinTemplate.html
样式调整的css路径：css/bulkPrinTemplate.css






